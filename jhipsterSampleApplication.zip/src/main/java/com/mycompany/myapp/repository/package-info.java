/**
 * Repository layer.
 */
package com.mycompany.myapp.repository;

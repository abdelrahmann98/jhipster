/**
 * Logging aspect.
 */
package com.mycompany.myapp.aop.logging;

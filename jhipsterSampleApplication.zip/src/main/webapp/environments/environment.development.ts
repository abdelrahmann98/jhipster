export const environment = {
  VERSION: 'DEV',
  DEBUG_INFO_ENABLED: true,
};
